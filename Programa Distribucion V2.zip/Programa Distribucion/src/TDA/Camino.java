package TDA;

public class Camino {
    public float distanciaTotal;
    public float tiempoTotal;
    public NodoGrafo origen;
    public NodoGrafo destino;
}
