package TDA;

import java.util.ArrayList;

public class NodoVivo {
    public ArrayList<Camino> solucionParcial;
    public float cotaInferior;
    public int etapa;
    public float kmParcial;
    public float tiempoParcial;
    public ArrayList<NodoGrafo> visitados;



}
