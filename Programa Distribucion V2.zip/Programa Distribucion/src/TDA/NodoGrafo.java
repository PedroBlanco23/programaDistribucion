package TDA;

import java.util.ArrayList;

public class NodoGrafo {
    public String nombre;
    public String cliente;
    public int horarioInicio;
    public int horarioFinal;


    public ArrayList<Camino> caminos;
}
