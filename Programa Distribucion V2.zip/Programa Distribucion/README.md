# programaDistribucion
Algoritmo en Java para realizar la distribución logística de una empresa, minimizando la cantidad de kilometros realizados.
